package dev.wanheng.springbootlibrary.dto;

import lombok.Data;

@Data
public class LoginResponseDto {
    private String token;
}
